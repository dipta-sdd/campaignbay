const PromotionSettings = ({ promotionSettings, setPromotionSettings }) => {
    return (
        <div className="wpab-cb-settings-tab">
            <h3>Promotion Settings</h3>
            <p>Configure promotion options here.</p>
        </div>
    );
};
export default PromotionSettings;

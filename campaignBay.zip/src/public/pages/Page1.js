export default function Page1() {
  return (
    <div>
      <h1>Page 1</h1>
      <p>This is the content of Page 1.</p>
    </div>
  );
}
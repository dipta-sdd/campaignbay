/** @type {import('tailwindcss').Config} */
module.exports = {
  prefix: "campaignbay-",
  content: ["./src/admin/**/*.{js,jsx,ts,tsx}"],
  plugins: [],
};

<?php //phpcs:ignore

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

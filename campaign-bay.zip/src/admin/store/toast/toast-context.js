import { createContext } from '@wordpress/element';

export const ToastContext = createContext(null);
const CampaignsAdd = () => {
    return (
        <div>
            <h1>Add Campaign</h1>
            <p>Use this page to add a new campaign.</p>
        </div>
    );
};

export default CampaignsAdd;

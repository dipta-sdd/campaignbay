import { CampaignsList } from "../components/DataList";

const Campaigns = () => {
    return (
        <div>
            <h1>Campaigns</h1>
            <p>List of all campaigns will be shown here.</p>
            <CampaignsList />
        </div>
    );
};

export default Campaigns;
